//importando un modulo
const operacionesMatematicas = require('./module');

console.log(operacionesMatematicas.resta(5, 3));

