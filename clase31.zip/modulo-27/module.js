const suma = (a, b) => a + b;
const resta = (a, b) => a - b;
const multiplicacion = (a, b) => a * b;
const division = (a, b) => a / b;

module.exports = {
    suma,
    resta,
    multiplicacion,
    division
}
