// console.log('hola nodejs');
// //nos devuelve la ruta donde estamos ejecutando nuestro codigo
// console.log(__dirname);

// //nos devuelve el nombre del archivo que estamos ejecutando
// console.log(__filename);

// //el objeto module nos permite acceder a las propiedades del modulo
// console.log(module);

// //el objeto require nos permite importar modulos
// console.log(require);

// //el objeto process nos permite acceder a las propiedades del proceso
// console.log(process);

// //el objeto exports nos permite exportar modulos
// console.log(exports);

// //setInterval nos permite ejecutar una funcion cada cierto tiempo
// setInterval(() => {
//     console.log('hola nodejs');
// }, 1000);

// //setTimeOut nos permite ejecutar una funcion una sola vez
// setTimeout(() => {
//     console.log('hola nodejs');
// }, 3000);

