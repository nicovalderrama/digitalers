let infoCars = { 
    nationals: [
        {id:1,car:"Suzuki",model:"SJ",year:1988},
        {id:2,car:"Mitsubishi",model:"Chariot",year:1985},
        {id:3,car:"Saab",model:"9-3",year:2006},
        {id:4,car:"Lincoln",model:"Continental Mark VII",year:1987},
        {id:5,car:"GMC",model:"Yukon",year:2000},
        {id:6,car:"Cadillac",model:"DeVille",year:2003},
        {id:7,car:"Dodge",model:"Ram Van B250",year:1992},
        {id:8,car:"Land Rover",model:"Defender",year:1995},
        {id:9,car:"GMC",model:"Yukon",year:1995},
        {id:10,car:"Kia",model:"Rondo",year:2008},
        {id:11,car:"BMW",model:"M5",year:2007},
        {id:12,car:"Subaru",model:"Loyale",year:1993},
        {id:13,car:"Kia",model:"Rio",year:2011},
        {id:14,car:"Scion",model:"xD",year:2008},
        {id:15,car:"Subaru",model:"Forester",year:2012},
        {id:16,car:"Volvo",model:"S40",year:2009},
        {id:17,car:"Saab",model:"9-5",year:2007},
        {id:18,car:"Ford",model:"Econoline E150",year:1997},
        {id:19,car:"Audi",model:"A6",year:1998},
    ],
    imported: [
        {id:20,car:"Lexus",model:"SC",year:1994},
        {id:21,car:"Toyota",model:"T100 Xtra",year:1998},
        {id:22,car:"Mitsubishi",model:"Eclipse",year:2000},
        {id:23,car:"Oldsmobile",model:"Achieva",year:1996},
        {id:24,car:"GMC",model:"Safari",year:2003},
        {id:25,car:"Volkswagen",model:"Golf",year:2006},
        {id:26,car:"Chevrolet",model:"G-Series 2500",year:1998},
        {id:27,car:"Porsche",model:"Boxster",year:1998},
        {id:28,car:"Honda",model:"Civic Si",year:2006},
        {id:29,car:"Dodge",model:"Ram Van 3500",year:1997},
        {id:30,car:"Mercedes-Benz",model:"S-Class",year:1984},
        {id:31,car:"Toyota",model:"Tercel",year:1994},
        {id:32,car:"Toyota",model:"Tacoma",year:2006},
        {id:33,car:"Volvo",model:"S60",year:2007},
        {id:34,car:"Mazda",model:"MX-6",year:1989},
        {id:35,car:"Saab",model:"900",year:1986},
        {id:36,car:"Geo",model:"Prizm",year:1992},
        {id:37,car:"Jaguar",model:"XK",year:2008},
        {id:38,car:"Subaru",model:"Legacy",year:2009},
        {id:39,car:"Ford",model:"F-Series",year:1996},
        {id:40,car:"Peugeot",model:"207",year:2006}
    ]
}

module.exports = {
    infoCars
}